<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='customers'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Payments | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1> Payments <a href="payments_add.php" class="btn bg-olive btn-sm pull-right" title="Add Payment">Add New Payment</a> </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->
              <div class="box">
                <div class="box-header">
                	 
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th width="10%">No</th>
                <th>Payment Date</th>
                <th>Payment Type</th>
                <th>Amount</th>
                
                      </tr>
                      
                    </thead>
                    
                    <tbody>
                    <?php $customers=$objMain->getResults("select * from cp_customer_payments where parent_id=".$id);
					if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
            $cus=$objMain->getRow("select * from cp_customers where customerid=".$customer['parent_id']);
					?>
                    <tr>
                        <td width="10%"><?php echo $i; ?></td>
                        <td><?php echo date("d-m-Y",strtotime($customer['payment_date'])); ?></td>
                <td><?php echo $customer['payment_type']; ?></td>
                <td><?php echo $customer['amount']; ?></td>
                
                      </tr>
                <?php } } ?>
                      
                      
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
  </body>
</html>
