<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='customers'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Pending Payment | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1> Pending Payment - Customers</h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->
              <div class="box">
                <div class="box-header">
                	 
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th width="10%">No</th>
                        
                <th>Customer Name</th>
                <th>GST NO</th>
                <th>Mobile Number</th>
                <th>Mail ID</th>
                <th>Pending Amount</th>
                <th>Actions</th>
                      </tr>
                      
                    </thead>
                    
                    <tbody>
                    <?php $customers=$objMain->getResults("select * from cp_customers where pending_amount>0 order by pending_amount desc");
					if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
					?>
                    <tr>
                        <td width="10%"><?php echo $i; ?></td>
                       <td><?php echo $customer['customername']; ?></td>
                <td><?php echo $customer['gstno']; ?></td>
                <td><?php echo $customer['contactno']; ?></td>
                <td><?php echo $customer['mail']; ?></td>
                <td><?php echo $objMain->formatInIndianStyleWithoutZero($customer['pending_amount']); ?></td>
                <td><a href="payments_history.php?id=<?php echo $customer['customerid']; ?>" class="btn bg-olive btn-xs" title="Update Supplier">Payment History</a></td>
                      </tr>
                <?php } } ?>
                      
                      
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
  </body>
</html>
