// JavaScript Document
function checkDelete(objValue)
	{
	if(confirm(objValue))
	 return true;
	else
	 return false;
	}

function limitText(limitField, limitCount, limitNum) {
	if (limitField.value.length > limitNum) {
		limitField.value = limitField.value.substring(0, limitNum);
	} else {
		limitCount.value = limitNum - limitField.value.length;
	}
}

function Image_Check(imagename){
    var extension=imagename.split('.').pop().toLowerCase();
    if ('jpeg'==extension || 'jpg'==extension){
        alert('extension ok !');
        return true;
    }else{
        alert('extension not allowed !');
        return false;
    }
}