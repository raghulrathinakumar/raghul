<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='dashboard'; 
$date_from=date_format(date_create(date("Y-m-1")),"Y-m-d");
$date_to=date_format(date_create(date("Y-m-d")),"Y-m-d");
$qry=" and invoice_date between '".$date_from."' and '".$date_to."'";
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Dashboard | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
<!-- Morris chart -->
    <link href="plugins/morris/morris.css" rel="stylesheet" type="text/css" />
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
         <div class="col-md-12">

         <div class="col-md-6">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Top Pending Payments</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Customer</th>
                    <th>Contact No</th>
                    <th>Pending Payment</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $customers=$objMain->getResults("select * from cp_customers where pending_amount>1 order by pending_amount desc limit 10");
          if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
          ?>
                  <tr>
                    <td><?php echo $customer['customername']; ?></td>
                    <td><?php echo $customer['contactno']; ?></td>
                    <td><?php echo $objMain->formatInIndianStyleWithoutZero($customer['pending_amount']); ?></td>
                    
                  </tr>
                  <?php } } ?>
                  
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <a href="pending_payments.php" class="btn btn-sm btn-info btn-flat pull-left">View All</a>
              
            </div>
            <!-- /.box-footer -->
          </div>
         </div>

         <div class="col-md-6">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Less Stock Products</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin">
                  <thead>
                  <tr>
                    <th>Product Name</th>
                    <th>Selling Name</th>
                    <th align="right">Stock</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $customers=$objMain->getResults("select * from cp_product_master order by stock asc limit 10");
          if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
          ?>
                  <tr>
                    <td><?php echo $customer['purchasename']; ?></td>
                    <td><?php echo $customer['sellingname']; ?></td>
                    <td align="right" style="padding-right: 20px;"><?php echo $objMain->makeComma($customer['stock']); ?></td>
                    
                  </tr>
                  <?php } } ?>
                  
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <a href="products.php" class="btn btn-sm btn-info btn-flat pull-left">View All</a>
              
            </div>
            <!-- /.box-footer -->
          </div>
         </div>

</div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>

      <!-- Control Sidebar -->
      <!-- /.control-sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php //include("inc/footer_scripts.php"); ?>
   <!-- jQuery 2.1.4 -->
    <script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js" type="text/javascript"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script type="text/javascript">
      $.widget.bridge('uibutton', $.ui.button);
    </script>
    <!-- Bootstrap 3.3.2 JS -->
    <script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- Morris.js charts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="plugins/morris/morris.min.js" type="text/javascript"></script>
    <!-- Sparkline -->
    <script src="plugins/sparkline/jquery.sparkline.min.js" type="text/javascript"></script>
    <!-- jvectormap -->
    <script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js" type="text/javascript"></script>
    <script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <!-- jQuery Knob Chart -->
    <script src="plugins/knob/jquery.knob.js" type="text/javascript"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js" type="text/javascript"></script>
    <script src="plugins/daterangepicker/daterangepicker.js" type="text/javascript"></script>
    <!-- datepicker -->
    <script src="plugins/datepicker/bootstrap-datepicker.js" type="text/javascript"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js" type="text/javascript"></script>
    <!-- Slimscroll -->
    <script src="plugins/slimScroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- FastClick -->
    <script src="plugins/fastclick/fastclick.min.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="dist/js/app.min.js" type="text/javascript"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="dist/js/pages/dashboard.js" type="text/javascript"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="dist/js/demo.js" type="text/javascript"></script>
   <script src="plugins/chartjs/ChartNew.js"></script>
    
    <script>

		var randomScalingFactor = function(){ return Math.round(Math.random()*100)};
		var lineChartData = {
			labels : [<?php $results=$objMain->getResults("select sum(amount) as cnt, invoice_date from cp_order where payment_status='success' ".$qry." group by invoice_date order by invoice_date");
if(!empty($results)) { foreach($results as $res) {  echo "'".date("dS",strtotime($res['invoice_date']))."',";  } }  ?>],
			datasets : [
				{
					label: "My First dataset",
					fillColor : "#3c8dbc",
					strokeColor : "rgba(220,220,220,1)",
					pointColor : "rgba(220,220,220,1)",
					pointStrokeColor : "#fff",
					scaleShowGridLines : true,
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(220,220,220,1)",
					data : [<?php $results=$objMain->getResults("select sum(amount) as cnt, invoice_date from cp_order where payment_status='success' ".$qry." group by invoice_date order by invoice_date");
if(!empty($results)) { foreach($results as $res) {  echo $res['cnt'].",";  } }  ?>]
				}
			]

		}

	window.onload = function(){
		var ctx = document.getElementById("canvas").getContext("2d");
		window.myLine = new Chart(ctx).Line(lineChartData, {
			responsive: true,
			legendBlockSize : 100,
      scaleLabel: "<%=value%>",
      legend : true,
	  yAxisLabel: "Count",
	  xAxisLabel:"Date"
		});

	}


	</script>
  </body>
</html>
