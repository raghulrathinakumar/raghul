<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='customers'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Payments | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1> Payments 
<?php if($acc_payments['access_add']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
          <a href="payments_add.php" class="btn bg-olive btn-sm pull-right" title="Add Payment">Add New Payment</a> 
<?php } ?>
          </h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->
              <div class="box">
                <div class="box-header">
                	 
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th width="10%">No</th>
                        
                <th>Customer Name</th>
                <th>Payment Type</th>
                <th>Amount</th>
                <th>Actions</th>
                      </tr>
                      
                    </thead>
                    
                    <tbody>
                    <?php $customers=$objMain->getResults("select * from cp_customer_payments");
					if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
            $cus=$objMain->getRow("select * from cp_customers where customerid=".$customer['parent_id']);
					?>
                    <tr>
                        <td width="10%"><?php echo $i; ?></td>
                       <td><?php echo $cus['customername']; ?></td>
                <td><?php echo $customer['payment_type']; ?></td>
                <td><?php echo $objMain->formatInIndianStyleWithoutZero($customer['amount']); ?></td>
                <td>
<?php if($acc_payments['access_edit']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
                <a href="payments_update.php?id=<?php echo $customer['id']; ?>" class="btn bg-olive btn-xs" title="Update Payment">Update</a> 
<?php } if($acc_payments['access_delete']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
                <a href="init.php?module=admin&action=customer_payment&do=delete&id=<?php echo $customer['id']; ?>" class="btn bg-olive btn-xs" title="Delete Payment" onClick="return checkDelete('Are You sure to Remove ?');">Delete</a>
<?php } ?>
                </td>
                      </tr>
                <?php } } ?>
                      
                      
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
  </body>
</html>
