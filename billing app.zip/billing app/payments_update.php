<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='cus_payment'; 
$pay=$objMain->getRow("select * from cp_customer_payments where id=".$id);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Payment Update | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Payment Update
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          
          <form role="form" class="form-horizontal" method="post" action="init.php?module=admin&action=customer_payment&do=update&id=<?php echo $id; ?>" enctype="multipart/form-data">
            <!-- left column -->
            <!--/.col (left) -->
            <!-- right column -->
            <div class="col-md-6">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  
                </div><!-- /.box-header -->
                <!-- form start -->
                
                  <div class="box-body">
                  <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Payment Date Date</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="payment_date" name="payment_date" value="<?php echo date("d-m-Y",strtotime($pay['payment_date'])); ?>" />
                      </div>
                    </div>
                  <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Customer Name</label>
                      <div class="col-sm-8">
                       <select id="customer" name="customer" class="form-control">
                      <?php $results=$objMain->getResults("select * from cp_customers");
            if(!empty($results)) { foreach($results as $result) { ?>
                      <option value="<?php echo $result['customerid']; ?>" <?php if($pay['parent_id']==$result['customerid']) echo "selected"; ?>><?php echo $result['customername']; ?></option>
                      <?php } } ?>
                      </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Amount</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" placeholder="Amount" id="amount" name="amount" required; value="<?php echo $pay['amount']; ?>" />
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Discount</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" placeholder="Discount" id="discount" name="discount" required;  value="<?php echo $pay['discount']; ?>"/>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Payment Mode</label>
                      <div class="col-sm-8">
                      <input type="radio" name="payment_type" id="cash" value="cash" <?php if($pay['payment_type']=='cash') echo "checked"; ?> onchange="show_info('cash');"> <label for="cash"> Cash</label>
                      <input type="radio" name="payment_type" id="cheque" value="cheque" <?php if($pay['payment_type']=='cheque') echo "checked"; ?> onchange="show_info('cheque');"> <label for="cheque"> Cheque</label>
                      <input type="radio" name="payment_type" id="neft" value="neft" <?php if($pay['payment_type']=='neft') echo "checked"; ?> onchange="show_info('neft');"> <label for="neft"> NEFT / IMPS</label>
                      </div>
                    </div>
                    
                    <div class="row" id="cheque_details" <?php if($pay['payment_type']!='cheque') echo "style='display:none'"; ?>>
                      
                      <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Cheque No</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control"  id="cheque_no" name="cheque_no" value="<?php echo $pay['cheque_no']; ?>" />
                      </div>
                    </div>

                      <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Cheque Date</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="cheque_date" name="cheque_date" value="<?php echo date("d-m-Y",strtotime($pay['cheque_date'])); ?>" />
                      </div>
                    </div>

                      <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Cheque Bank</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" id="cheque_bank" name="cheque_bank" value="<?php echo $pay['cheque_bank']; ?>" />
                      </div>
                    </div>
                    </div>
                    <div class="row" id="neft_details" <?php if($pay['payment_type']!='neft') echo "style='display:none'"; ?>>
                      
                      <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">NEFT / IMPS Reff No</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control"  id="neft_reffno" name="neft_reffno" value="<?php echo $pay['neft_reffno']; ?>"/>
                      </div>
                    </div>

                      
                    </div>
                   
                    
                    <div class="box-footer">
                    <button type="submit" class="btn btn-info pull-right">Submit</button>
                  </div>
                    
                  </div><!-- /.box-body -->
                
              </div><!-- /.box -->
              <!-- general form elements disabled -->
              <!-- /.box -->
            </div><!--/.col (right) -->
            
            
            
            
            
            </form>
          </div>
          
          
        <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
 <script type="text/javascript">
      $(function () {
        $("#cheque_date").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
        $("#payment_date").inputmask("dd-mm-yyyy", {"placeholder": "dd-mm-yyyy"});
    });
      function show_info(type){ 
        document.getElementById("cheque_details").style.display="none";
        document.getElementById("neft_details").style.display="none";

        if(type=='cheque')
          document.getElementById("cheque_details").style.display="block";
        if(type=='neft')
          document.getElementById("neft_details").style.display="block";
         
      }
</script>
  </body>
</html>
