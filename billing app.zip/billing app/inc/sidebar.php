<?php 
$mnu_dashboard="";
$mnu_customers="";
$mnu_suppliers="";
$mnu_product="";
$mnu_purchase="";
$mnu_sales="";
$mnu_tickets="";
$mnu_cus_payments="";
$mnu_employees="";
$mnu_salary="";
if($menu=='dashboard') $mnu_dashboard="active";
if($menu=='customers')  $mnu_customers="active"; 
if($menu=='suppliers') $mnu_suppliers="active";
if($menu=='products') $mnu_product="active";
if($menu=='purchase') $mnu_purchase="active";
if($menu=='sales') $mnu_sales="active";
if($menu=='cus_payment') $mnu_cus_payments="active";
if($menu=='tickets') $mnu_tickets="active";
if($menu=='stock') $mnu_stock="active";
if($menu=='salary') $mnu_salary="active";

$acc_customer=$objMain->getRow("select * from cp_access where module='customer' and parent_id='".$_SESSION['admin_id']."'");
$acc_supplier=$objMain->getRow("select * from cp_access where module='supplier' and parent_id='".$_SESSION['admin_id']."'");
$acc_purchase=$objMain->getRow("select * from cp_access where module='purchase' and parent_id='".$_SESSION['admin_id']."'");
$acc_sales=$objMain->getRow("select * from cp_access where module='sales' and parent_id='".$_SESSION['admin_id']."'");
$acc_payments=$objMain->getRow("select * from cp_access where module='payments' and parent_id='".$_SESSION['admin_id']."'");
$acc_products=$objMain->getRow("select * from cp_access where module='products' and parent_id='".$_SESSION['admin_id']."'");
$acc_reports=$objMain->getRow("select * from cp_access where module='reports' and parent_id='".$_SESSION['admin_id']."'");


?>
<aside class="main-sidebar">
        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar user panel -->
          <!--<div class="user-panel">
            <div class="pull-left image">
              <img src="dist/img/jamex.png" class="img-circle" alt="User Image" />
            </div>
            <div class="pull-left info">
              <p>Alexander Pierce</p>
              <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
          </div>-->
          <!-- search form -->
          
          <!-- /.search form -->
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
          
            <li class="treeview <?php echo $mnu_dashboard; ?>">
              <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
              </a>
            </li>
           
           
            
            
            <?php if($acc_sales['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_sales; ?>">
              <a href="sales.php">
                <i class="fa fa-database"></i> <span>Sales</span>
              </a>
            </li>
            <?php } if($acc_payments['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_cus_payments; ?>">
              <a href="payments.php">
                <i class="fa fa-money"></i> <span>Payments</span>
              </a>
            </li>
            <?php } if($acc_products['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_product; ?>">
              <a href="products.php">
                <i class="fa fa-cubes"></i> <span>Products / Stocks</span>
              </a>
            </li>
            <?php } if($acc_purchase['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
             <li class="treeview <?php echo $mnu_purchase; ?>">
              <a href="purchase.php">
                <i class="fa fa-shopping-cart"></i> <span>Purchase</span>
              </a>
            </li>
            <?php } if($acc_customer['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_customers; ?>">
              <a href="customers.php">
                <i class="fa fa-users"></i> <span>Customers</span>
              </a>
            </li>
            <?php } if($acc_supplier['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_suppliers; ?>">
              <a href="suppliers.php">
                <i class="fa fa-user-secret"></i> <span>Suppliers</span>
              </a>
            </li>
            <?php } if($_SESSION['category']=='primary_admin'){ ?>
            <li class="treeview <?php echo $mnu_users; ?>">
              <a href="users.php">
                <i class="fa fa-child"></i> <span>Users</span>
              </a>
            </li>
            <?php } if($acc_reports['access_view']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
             <li class="treeview <?php echo $mnu_salary; ?>">
              <a href="#">
                <i class="fa fa-newspaper-o"></i>
                <span>Reports</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
              <li><a href="pending_payments.php"><i class="fa fa-money"></i> Pending Payment</a></li>
              <li><a href="sales_report.php"><i class="fa fa-money"></i> Sales Report</a></li>
              <li><a href="purchase_report.php"><i class="fa fa-money"></i> Purchase Report</a></li>
              </ul>
            </li>
           <?php } ?>
            
         
          </ul>
        </section>
        <!-- /.sidebar -->
      </aside>