<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.2.0
        </div>
       <!-- <strong>Copyright &copy; 2015-2016 <a href="http://cinaple.com" target="_blank">Cinaple</a>.</strong> All rights reserved. -->
      </footer>