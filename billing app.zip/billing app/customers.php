<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='customers'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Customers | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1> Customers 
<?php if($acc_customer['access_add']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
          <a href="customers_add.php" class="btn bg-olive btn-sm pull-right" title="Add Customer">Add New Customer</a> 
<?php } ?>
</h1>
          
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <!-- /.box -->
              <div class="box">
                <div class="box-header">
                	 
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                      <tr>
                        <th width="10%">No</th>
                        
                <th>Customer Name</th>
                <th>GSTIN</th>
                <th>Mobile Number</th>
                <th>Mail ID</th>
                <th>Pending Amount</th>
                <th>Actions</th>
                      </tr>
                      
                    </thead>
                    
                    <tbody>
                    <?php $customers=$objMain->getResults("select * from cp_customers");
					if(!empty($customers)) { $i=0; foreach($customers as $customer) { $i++; 
					?>
                    <tr>
                        <td width="10%"><?php echo $i; ?></td>
                       <td><?php echo $customer['customername']; ?></td>
                <td><?php echo $customer['gstno']; ?></td>
                <td><?php echo $customer['contactno']; ?></td>
                <td><?php echo $customer['mail']; ?></td>
                <td><?php echo $objMain->formatInIndianStyleWithoutZero($customer['pending_amount']); ?></td>
                <td>
<?php if($acc_customer['access_edit']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
                <a href="customers_update.php?id=<?php echo $customer['customerid']; ?>" class="btn bg-olive btn-xs" title="Update Supplier">Update</a> 
<?php } if($acc_customer['access_delete']=='yes' || $_SESSION['category']=='primary_admin'){ ?>
                <a href="init.php?module=admin&action=customers&do=delete&id=<?php echo $customer['customerid']; ?>" class="btn bg-olive btn-xs" title="Delete Customer" onClick="return checkDelete('Are You sure to Remove ?');">Delete</a>
<?php } ?>
                </td>
                      </tr>
                <?php } } ?>
                      
                      
                    </tbody>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
  </body>
</html>
