<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='password'; ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Change Password | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Change Password
          </h1>
          
          <?php
    if(isset($msg) && $msg=='suc') { $atype="success";
    $msg="Password Updated successfully"; }
	if(isset($msg) && $msg=='invalid') { $atype="danger";
    $msg="User Name / Old Password Invalid"; }
	?>
    <?php if(isset($msg)) { ?>
      <div class="alert alert-<?php echo $atype; ?> alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <p><i class="icon fa fa-ban"></i> <?php echo $msg; ?></p>
      </div>
          <?php } ?>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          
          <form role="form" class="form-horizontal" method="post" action="init.php?module=admin&action=changepassword&do=update" enctype="multipart/form-data">
            <!-- left column -->
            <!--/.col (left) -->
            <!-- right column -->
            <div class="col-md-6">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">&nbsp;</h3>
                </div><!-- /.box-header -->
                <!-- form start -->
                
                  <div class="box-body">
                  <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">User Name</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" name="username" id="username" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Old Password</label>
                      <div class="col-sm-8">
                      <input type="password" class="form-control" name="olduserpassword" id="olduserpassword" required>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">New Password</label>
                      <div class="col-sm-8">
                      <input type="password" class="form-control" name="userpassword" id="userpassword" required>
                      </div>
                    </div>
                    
                    
                    <div class="box-footer">
                    <button type="submit" class="btn btn-info pull-right">Change</button>
                  </div>
                    
                  </div><!-- /.box-body -->
                
              </div><!-- /.box -->
              <!-- general form elements disabled -->
              <!-- /.box -->
            </div><!--/.col (right) -->
            
            
            
            
            
            
            
            </form>
          </div>
          
          
        <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
<script type="text/javascript">

function load_cats(type,id){

$.ajax({
'url' : "lib/category_ajax.php",
'type' : 'POST', //the way you want to send data to your URL
'data' : {'id' : id , 'type' : type},
'success' : function(data){
	eval(data);
}
});
}
</script> 
  </body>
</html>
