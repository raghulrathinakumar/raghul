<?php include("lib/common.php"); 
$invoice=$objMain->getRow("select * from cp_sales where id=".$id);
$customer=$objMain->getRow("select * from cp_customers where customerid =".$invoice['parent_id']);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" moznomarginboxes mozdisallowselectionprint>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Invoice | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
<style>
table { border-top:none; }
th { text-align:center; background:#999; border-top:none; }
td { text-align:right; padding-right:5px; }
td:nth-child(2) { text-align:left; }
@media print {
    #Header, #Footer { display: none !important; }
}
@page { margin: 10px 30px; }
#Header, #Footer { display: none !important; }
.inv { border:solid 1px; }
.inv td { border-right:solid 1px;}
.inv th, .inv .lastrow { border:solid 1px; }
.inv .lastrow td:nth-child(1) { text-align:left; padding-left:10px; }
table tr:nth-child(1) td { padding-top: 10px;  }
table tr td { padding-bottom: 10px; }
</style>
</head>

<body>
<div style="float:left; width:900px; padding:20px 10px;">
<h3 align="center">Tax Invoice</h3>
<div style="float:left; width:900px; border:1px solid;">
	<div style="float:left;width:150px;padding: 5px 20px;">
    	 <img src="logo.png">
	</div>
    <div style="float:left;width:350px;border-right:1px solid;">
    	<span style="font-size:16px; font-weight:bold;">HITECH SOLUTIONS</span><br />
     #41, 1st Floor, Kumar Nagar East, 1<sup>st</sup> Street, <br>Opp. Naidu Sangam, TIrupur - 641 603
     <br>Contact : +91 8489 8489 79
     <br>Email: hitechsolutions.service@gmail.com
    
    </div>
    <div style="float:left; height:100%; line-height: 27px;">
    <div style="float:left; width:200px; height:100%; padding:10px; font-weight: bold;">Invoice No<br />Invoice Date<br>GSTIN</div>
    <div style="float:left; padding:10px;">2017-2018/<?php if($invoice['bill_type']=='sales') echo "SI";
else if($invoice['bill_type']=='service') echo "SRI";
else if($invoice['bill_type']=='renewal') echo "RI";
else if($invoice['bill_type']=='both') echo "SS"; ?>/<?php if($invoice['invoice_no']<10) echo "000".$invoice['invoice_no'];
else if($invoice['invoice_no']<100) echo "00".$invoice['invoice_no'];
else if($invoice['invoice_no']<100) echo "0".$invoice['invoice_no'];
else echo $invoice['invoice_no']; ?><br /><?php echo date("d-m-Y",strtotime($invoice['invoice_date'])); ?>
  <br>33BBAPD6581M1ZL
  </div>
    </div>
</div>
<div style="float:left; min-height:80px; width:900px; border:1px solid;">
	<div style="float:left; width:500px; border-right:1px solid; ">
    <div style="float:left; padding:10px; font-weight: bold;">Billing To</div>
    <div style="float:left; width:400px; padding:10px;"><?php echo $customer['customername']; ?><br /><?php echo $customer['address']; ?><br>
    GSTIN: <?php echo $customer['gstno']; ?></div>
    </div>
    <div style="float:left;  ">
    <div style="float:left; padding:10px; font-weight: bold;">Shipping To</div>
    <div style="float:left; width:300px; padding:10px;"><?php echo $customer['customername']; ?><br /><?php echo $customer['address']; ?><br>
    GSTIN: <?php echo $customer['gstno']; ?></div>
    </div>
</div>
<div style="float:left; width:900px; font-weight:bold;">
<table border="0" style="width:100%;" class="inv">
                <thead>
                  <tr>
                    <th width="50">S.No</th>
                    <th width="500">Particulars</th>
                    <th width="160">HSN / SAC No</th>
                    <th width="80">QTY</th>
                    <th width="100">Rate</th>
                    <th width="100">Discount</th>
                    <th width="100">GST</th>                    
                    <th width="100">Amount</th>
                  </tr>
                </thead>
                <tbody>
                <?php
				$results=$objMain->getResults("select * from cp_sales_products where parent_id=".$id);
        $percen_18=0; $percen_18_value=0; $percen_18_gst=0;
        $percen_28=0; $percen_28_value=0; $percen_28_gst=0;
        $percen_5=0; $percen_5_value=0; $percen_5_gst=0;

				if(!empty($results)) { $i=0; $sno=0; $total=0; foreach($results as $result){ $i++; $sno++;
          $particulars='';
          if($result['product_id']!=-1){
				$product=$objMain->getRow("select * from cp_product_master where productid=".$result['product_id']);
        $particulars.=$product['sellingname']."<br>";        
				}
        $particulars.=$result['description'];
        $i+=round((strlen($particulars)/50), 0, PHP_ROUND_HALF_DOWN);
        if($result['gstpercen']==28) {$percen_28=1; $percen_28_gst+=$result['gstamount']; $percen_28_value+=$result['total_amount']; }
        if($result['gstpercen']==18) { $percen_18=1; $percen_18_gst+=$result['gstamount']; $percen_18_value+=$result['total_amount']; }
        if($result['gstpercen']==5) { $percen_5=1; $percen_5_gst+=$result['gstamount']; $percen_5_value+=$result['total_amount']; }
				?>
                  <tr>
                    <td style="text-align: center;" valign="top"> <?php echo $sno; ?></td>
                    <td style="padding-left:5px;" valign="top"> <?php echo $particulars; ?></td>
                    <td style="text-align: center; padding-left: 10px;" valign="top"> <?php echo $product['hsnno']; ?></td>
                    <td style="text-align: center;" valign="top"> <?php echo $result['qty']; ?></td>
                    <td valign="top"> <?php echo $objMain->formatInIndianStyle($result['rate']); ?></td>
                    <td valign="top"> <?php echo $objMain->formatInIndianStyle($result['discount']); ?></td>
                    <td style="text-align: center;" valign="top"> <?php echo $result['gstpercen']; ?>%</td>
                    
                    <td valign="top"> <?php echo $objMain->formatInIndianStyle($result['total_amount']); ?></td>                    
                  </tr>
             <?php } } 
			 ?>     
                  <?php for(;$i<16;$i++) { ?>
                  <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  </tr>
                  <?php } ?>
                  
                  <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td style="text-align: center;">Total</td>                  
                  <td><?php echo $objMain->formatInIndianStyle($invoice['total_amount']); ?></td>
                  </tr>
                  <tr style="border-top:1px solid; ">
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td style="text-align: center;">Value</td>
                  <td style="text-align: center;">CGST</td>
                  <td style="text-align: center;">SGST</td>
                  <td style="text-align: center;">IGST</td>
                  <td style="text-align: center;">GST</td>                  
                  <td>&nbsp;</td>
                  </tr>
                  <?php if($percen_28==1) { ?>
                  <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td style="text-align: center;"><?php echo $objMain->formatInIndianStyle($percen_28_value); ?></td>
                  <td style="text-align: center;">14%</td>
                  <td style="text-align: center;">14%</td>
                  <td style="text-align: center;">-</td>
                  <td style="text-align: center;">28%</td>                  
                  <td><?php echo $objMain->formatInIndianStyle($percen_28_gst); ?></td>
                  </tr>
                  <?php } ?>
                  <?php if($percen_18==1) { ?>
                  <tr>
                  <td>&nbsp;</td>
                  <td>&nbsp;</td>
                  <td style="text-align: center;"><?php echo $objMain->formatInIndianStyle($percen_18_value); ?></td>
                  <td style="text-align: center;">9%</td>
                  <td style="text-align: center;">9%</td>
                  <td style="text-align: center;">-</td>
                  <td style="text-align: center;">18%</td>                  
                  <td><?php echo $objMain->formatInIndianStyle($percen_18_gst); ?></td>
                  </tr>
                  <?php } ?>
                  
                  <tr class="lastrow">
                    <td colspan="5" align="right"><b>Amount Chargable(in Words):</b> <?php echo ucfirst($objMain->convert_number_to_words($invoice['net_amount'])); ?> Only</td>
                    <td colspan="2" align="right" style="padding-left:10px;">Total Amount</td>
                    <td><?php echo $objMain->formatInIndianStyle($invoice['net_amount']); ?></td>
                  </tr>
                   <tr class="lastrow">
                    <td colspan="5" rowspan="2" align="right" style="font-weight: normal;"><b>Terms & Conditions:</b> <?php echo 'All hardware provided by HITECH SOLUTIONS is covered under one year warranty & one year tracking from the date of installation. Warranty support will be provided at the place of original installation or mutually agreed based on vehicle schedule. Warranty support covers interruptions in service due to issue arising out of manufacturing defect only. '; ?></td>
                    <td colspan="2" align="right" style="padding-left:10px;">Round Off</td>
                    <td style="text-align:right"><?php echo 0; ?></td>
                  </tr>
                  <tr class="lastrow">
                    <td colspan="2" align="right" style="padding-left:10px;">Net Amount</td>
                    <td style="text-align:right;"><?php echo $objMain->formatInIndianStyle($invoice['net_amount']); ?></td>
                  </tr>
                  <tr class="lastrow" style="border-bottom:none;">
                    <td colspan="5" style="border: none;">&nbsp;</td>
                    <td colspan="3" style="text-align:center; ">For Company Name Solutions</td>
                  </tr>
                  <tr class="lastrow" style="border-bottom:none;border-top:none; ">
                    <td colspan="5" style="border: none;">&nbsp;</td>
                    <td colspan="3">&nbsp;</td>
                  </tr>
                  <tr class="lastrow" style="border-top:none;">
                    <td colspan="5" style="border: none;">&nbsp;</td>
                    <td colspan="3" style="text-align:center;">Authorized Signature</td>
                  </tr>
                </tbody>
              </table>
              <h6 align="center">This is a computer generated invoice. There is no need of signature.</h6>
</div>
</div>
<script type="text/javascript">window.print();</script>
</body>
</html>