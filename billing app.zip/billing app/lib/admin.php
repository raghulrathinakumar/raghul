<?php
global $objAdmin;
class Admin extends Main
{
	public function Postvalue($x)
	{
	$x = $_POST[$x];
	/*$x = str_replace("'","&#39;",$x);
	$x = str_replace("<","",$x);
	$x = str_replace(">","",$x);
	$x = htmlentities($x, ENT_QUOTES); //ENT_QUOTES – Decodes double and single quotes*/
	$x = mysql_real_escape_string($x); 
	return $x;
	}
	public function rand_string( $length ) {
	$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";	

	$size = strlen( $chars );
	for( $i = 0; $i < $length; $i++ ) {
		$str .= $chars[ rand( 0, $size - 1 ) ];
	}

	return $str;
    }
	public function gen_md5_password($len = 6)
	{
	// function calculates 32-digit hexadecimal md5 hash
	// of some random data
	return substr(md5(rand().rand()), 0, $len);
	}
    public function getResultscount($query) {
				
		$result = mysql_query($query);
		$totalCounts = @mysql_num_rows($result);
		return $totalCounts;
	}
	public function getRow($query) { 
		//var_dump($query);
		$result = mysql_query($query) or die("Cannot execute the query");
		$row = mysql_fetch_array($result,MYSQL_ASSOC);
		return $row;
	}
	public function redirectUrl($url){
		echo '<SCRIPT language="JavaScript">
			<!--
			window.location="'.$url.'";
			//-->
		</SCRIPT>';
	}
	public function ajaxredirectUrl($url){
		echo 'window.location="'.$url.'";';
	}
		public function deleteenquiry($id)
	{
    extract($_REQUEST);
	mysql_query("delete from  tbl_req_quote where enq_id =".$id."") or die(mysql_error());
	header("location: enquiry.php?msg=del");
	}
	public function updateImages($id)
	{
    extract($_REQUEST);
	//die("update carimages set status='yes' where id =".$image_id);
	mysql_query("update carimages set status='no' where car_id =".$id) or die(mysql_error());
	mysql_query("update carimages set status='yes' where id =".$image_id) or die(mysql_error());
	header("location: images.php?msg=upd&id=".$id);
	}
	public function deleteImages($id)
	{
    extract($_REQUEST);
	$carid=$this->getRow("select * from carimages where id =".$id);
	unlink("../imgs/".$carid['image_name']);
	mysql_query("delete from  carimages where id =".$id."") or die(mysql_error());
	header("location: images.php?msg=del&id=".$carid['car_id']);
	}

}
$objAdmin = new Admin();
?>