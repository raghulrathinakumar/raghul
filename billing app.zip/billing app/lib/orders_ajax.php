<?php
extract($_REQUEST);
require_once 'connection.php';
require_once 'functions.php';
if($_REQUEST['type']=='order') {
		
		echo "document.getElementById('orderid').options.length=0;";	
		echo "document.getElementById('particulars').options.length=0;";	
		echo "document.getElementById('qty').value='';";	
		
		$qry="select * from cp_order where customer=".$_REQUEST['id']." and status in ('new')";
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=1;		
		echo "document.getElementById('orderid').options[0]=new Option('Select','0');";
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('orderid').options[$i]=new Option('".str_replace("'","",ucfirst($row['style']))."','".$row['id']."');";
		$i++;
		} }	
}
if($_REQUEST['type']=='parti') {
		
		echo "document.getElementById('particulars').options.length=0;";	
		echo "document.getElementById('qty').value='';";	
		
		$qry="select * from cp_order_details where parent_id=".$_REQUEST['id'];
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=0;		
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('particulars').options[$i]=new Option('".str_replace("'","",ucfirst($row['particulars']))."','".$row['id']."');";
		$i++;
		} }	
}
if($_REQUEST['type']=='deli') {
		
		echo "document.getElementById('particulars').options.length=0;";	
		echo "document.getElementById('qty').value='';";	
		
		$qry="select * from cp_order_details where parent_id=".$_REQUEST['id'];
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=0;		
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('particulars').options[$i]=new Option('".str_replace("'","",ucfirst($row['particulars']))."','".$row['id']."');";
		$i++;
		} }	
}
?>