<?php
extract($_REQUEST);
require_once 'connection.php';
require_once 'functions.php';
if($_REQUEST['type']=='combo') {
		
		echo "document.getElementById('combo').options.length=0;";	
		echo "document.getElementById('work').options.length=0;";	
		echo "document.getElementById('qty').value='';";	
		
		$qry="select * from cp_workstyles where id in (select wstyle from cp_order_works where parent_id='".$_REQUEST['id']."')";
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=1;		
		echo "document.getElementById('combo').options[0]=new Option('Select','0');";
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('combo').options[$i]=new Option('".str_replace("'","",ucfirst($row['workstyle']))."','".$row['id']."');";
		$i++;
		} }	
}
if($_REQUEST['type']=='work') {
		
		echo "document.getElementById('work').options.length=0;";	
		echo "document.getElementById('qty').value='';";	
		
		$qry="select * from cp_order_works where work=".$_REQUEST['jobtype']." and parent_id='".$_REQUEST['orderid']."' and wstyle=".$_REQUEST['id'];
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=1;		
		echo "document.getElementById('work').options[0]=new Option('Select','0');";		
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('work').options[$i]=new Option('".str_replace("'","",ucfirst($row['worktype']))."','".$row['id']."');";
		$i++;
		} }	
}
if($_REQUEST['type']=='rate') {
		
		echo "document.getElementById('rate').value='';";	
		
		$qry="select * from cp_order_works where id=".$_REQUEST['id'];
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=0;		
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('rate').value='".$row['rate']."';";	
		$i++;
		} }	
}
if($_REQUEST['type']=='sal') {
		echo "document.getElementById('bsalary').value='';";	
		
		$qry="select * from cp_employees where id=".$_REQUEST['id'];
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=0;		
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('bsalary').value='".$row['salary']."';";	
		$i++;
		} }	
}
if($_REQUEST['type']=='add') {
		
		if($rate!="" && $rate!=0 && $work!=""){
			if(!isset($_SESSION['items'])){ 
				$_SESSION['items'][0]['orderid']=$orderid;
				$_SESSION['items'][0]['combo']=$combo;
				$_SESSION['items'][0]['work']=$work;
				$_SESSION['items'][0]['qty']=$qty;				
				$_SESSION['items'][0]['rate']=$rate;
			} else if(count($_SESSION['items'])==0){ 
				$_SESSION['items'][0]['orderid']=$orderid;
				$_SESSION['items'][0]['combo']=$combo;
				$_SESSION['items'][0]['work']=$work;
				$_SESSION['items'][0]['qty']=$qty;				
				$_SESSION['items'][0]['rate']=$rate;
			} else if(count($_SESSION['items'])>0){ 
				$keys = array_keys($_SESSION['items']);
				$last = end($keys);
				$id=$last+1; 
				$_SESSION['items'][$id]['orderid']=$orderid;
				$_SESSION['items'][$id]['combo']=$combo;
				$_SESSION['items'][$id]['work']=$work;
				$_SESSION['items'][$id]['qty']=$qty;
				$_SESSION['items'][$id]['rate']=$rate;
			}
		}
		$msg=''; $i=0; $total=0;
		foreach($_SESSION['items'] as $key=>$item){		$i++;
			$workname=$objMain->getRow("select * from cp_order_works where id=".$item['work']);
			$comboname=$objMain->getRow("select * from cp_workstyles where id=".$item['combo']);
			$amount=$item['rate']*$item['qty']; $total+=$amount;
			$msg.='<tr><td>'.$i.'</td><td>'.$item['orderid'].'</td><td>'.$comboname['workstyle'].'</td><td>'.$workname['worktype'].'</td><td>'.$item['qty'].'</td><td>'.$item['rate'].'</td><td>'.$amount.'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
			$msg.='<tr><td colspan="6" align="right"><b>Salary : </b></td><td>'.$total.'</td><td>&nbsp;</td></tr>';
		echo $msg;
} else if($_REQUEST['type']=='update') {
		
		unset($_SESSION['items'][$id]);
		$msg=''; $i=0; $total=0;
		foreach($_SESSION['items'] as $key=>$item){		$i++;
			$workname=$objMain->getRow("select * from cp_order_works where id=".$item['work']);
			$comboname=$objMain->getRow("select * from cp_workstyles where id=".$item['combo']);
			$amount=$item['rate']*$item['qty']; $total+=$amount;
			$msg.='<tr><td>'.$i.'</td><td>'.$item['orderid'].'</td><td>'.$comboname['workstyle'].'</td><td>'.$workname['worktype'].'</td><td>'.$item['qty'].'</td><td>'.$item['rate'].'</td><td>'.$amount.'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
			$msg.='<tr><td colspan="6" align="right"><b>Salary : </b></td><td>'.$total.'</td><td>&nbsp;</td></tr>';			
		echo $msg;
}
?>