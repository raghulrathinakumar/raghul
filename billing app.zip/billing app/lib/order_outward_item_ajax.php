<?php
extract($_REQUEST);
require_once 'connection.php';
require_once 'functions.php';
if($_REQUEST['type']=='add') {
		
		if($qty!=0 && $qty!=""){
			if(!isset($_SESSION['items'])){ 
				$_SESSION['items'][0]['item']=$particulars;
				$_SESSION['items'][0]['qty']=$qty;
			} else if(count($_SESSION['items'])==0){ 
				$_SESSION['items'][0]['item']=$particulars;
				$_SESSION['items'][0]['qty']=$qty;
			} else if(count($_SESSION['items'])>0){ 
				$keys = array_keys($_SESSION['items']);
				$last = end($keys);
				$id=$last+1;
				$_SESSION['items'][$id]['item']=$particulars;
				$_SESSION['items'][$id]['qty']=$qty;
			}
		}
		$msg='';
		foreach($_SESSION['items'] as $key=>$item){
			$res=$objMain->getRow("select * from cp_order_details where id=".$item['item']);
			
			$msg.='<tr><td>'.$res['particulars'].'</td><td>'.$item['qty'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
		echo $msg;
} else if($_REQUEST['type']=='update') {
		
		unset($_SESSION['items'][$id]);
		$msg='';
		foreach($_SESSION['items'] as $key=>$item){
			$res=$objMain->getRow("select * from cp_order_details where id=".$item['item']);
			$msg.='<tr><td>'.$res['particulars'].'</td><td>'.$item['qty'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
		echo $msg;
}
?>