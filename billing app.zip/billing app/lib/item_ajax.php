<?php
extract($_REQUEST);
require_once 'connection.php';
require_once 'functions.php';
if($_REQUEST['type']=='add') {
		
		if(($size1_qty!=0 && $size1_qty!="") || ($size2_qty!=0 && $size2_qty!="") || ($size3_qty!=0 && $size3_qty!="") || ($size4_qty!=0 && $size4_qty!="") || ($size5_qty!=0 && $size5_qty!="") ){
			if(!isset($_SESSION['items'])){ 
				$_SESSION['items'][0]['item']=$combo;
				$_SESSION['items'][0]['qty1']=$size1_qty;
				$_SESSION['items'][0]['qty2']=$size2_qty;
				$_SESSION['items'][0]['qty3']=$size3_qty;
				$_SESSION['items'][0]['qty4']=$size4_qty;
				$_SESSION['items'][0]['qty5']=$size5_qty;
			} else if(count($_SESSION['items'])==0){ 
				$_SESSION['items'][0]['item']=$combo;
				$_SESSION['items'][0]['qty1']=$size1_qty;
				$_SESSION['items'][0]['qty2']=$size2_qty;
				$_SESSION['items'][0]['qty3']=$size3_qty;
				$_SESSION['items'][0]['qty4']=$size4_qty;
				$_SESSION['items'][0]['qty5']=$size5_qty;
			} else if(count($_SESSION['items'])>0){ 
				$keys = array_keys($_SESSION['items']);
				$last = end($keys);
				$id=$last+1;
				$_SESSION['items'][$id]['item']=$combo;
				$_SESSION['items'][$id]['qty1']=$size1_qty;
				$_SESSION['items'][$id]['qty2']=$size2_qty;
				$_SESSION['items'][$id]['qty3']=$size3_qty;
				$_SESSION['items'][$id]['qty4']=$size4_qty;
				$_SESSION['items'][$id]['qty5']=$size5_qty;
			}
		}
		$msg='';
		foreach($_SESSION['items'] as $key=>$item){			
			$msg.='<tr><td>'.$item['item'].'</td><td>'.$item['qty1'].'</td><td>'.$item['qty2'].'</td><td>'.$item['qty3'].'</td><td>'.$item['qty4'].'</td><td>'.$item['qty5'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
		echo $msg;
} else if($_REQUEST['type']=='update') {
		
		unset($_SESSION['items'][$id]);
		$msg='';
		foreach($_SESSION['items'] as $key=>$item){
			$msg.='<tr><td>'.$item['item'].'</td><td>'.$item['qty1'].'</td><td>'.$item['qty2'].'</td><td>'.$item['qty3'].'</td><td>'.$item['qty4'].'</td><td>'.$item['qty5'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">'.Remove.'</a></td></tr>';
		}
		echo $msg;
}
?>