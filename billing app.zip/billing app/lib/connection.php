<?php

ob_start();

session_start();

// HTTP
define('HTTP_SERVER', 'http://localhost/balaji/');
define('HTTP_ADMIN', 'http://localhost/balaji/cp-admin/');
// HTTPS
define('HTTPS_SERVER', 'https://localhost/balaji/');

// DIR
define('DIR_APPLICATION', 'C:\xampp\htdocs\balaji/');
define('DIR_IMAGE', 'C:\xampp\htdocs\balaji/');
define('DIR_AD_IMG', 'C:\xampp\htdocs\balaji\ads/');
define('DIR_LIB', 'C:\xampp\htdocs\balaji\cp-admin/lib/');
define('DIR_PDF', 'D:\xampp\htdocs\hts/pdf/');
define('DIR_LIBRARY', 'C:\xampp\htdocs\balaji\cp-admin\library/');
class Connection {

	var $hostname, $username, $password, $database;

function __construct() {

		$this->hostname = "localhost";//Database host.

		$this->username = "root"; //Database username.

		$this->password = ""; //Database password.

		$this->database = "hitech";//Database.local
	

		$this->dbConnection(); 

	}

	

	

	public function dbConnection () {

		$connection = mysql_connect($this->hostname,$this->username,$this->password) or die ('Cannot make a connection');

		if ($connection) {

			$selectDB = mysql_select_db($this->database) or die ('Cannot select database');

		}

	}

}

$connect = new Connection();
date_default_timezone_set('Asia/Kolkata');
extract($_REQUEST);
?>