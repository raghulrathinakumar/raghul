<?php
require_once "lib/functions.php";
global $objFeatures;
class Features extends Main
{
	public function UpdatePassword(){
		extract($_REQUEST);
		mysql_query("update cp_admin set username='".$username."',userpassword='".md5($userpassword)."' where admin_id=".$_SESSION['admin_id']);
		session_destroy();
		$this->redirectUrl("index.php?logout");
	}

	public function ChangePasswordUsers($id){
		extract($_REQUEST);
		mysql_query("update cp_admin set userpassword='".md5($userpassword)."' where admin_id=".$id);
		header("location:users.php?msg=pass");
	}

	/* Customer */
	public function AddCustomer() { extract($_REQUEST); 
			$customername=$this->clean('customer_name');			
			$mail=$this->clean('mail');
			$address=$this->clean('address');
			$mobile=$this->clean('mobile');
			$gstno=$this->clean('gstno');
			mysql_query("insert into cp_customers set customername='".$customername."',address='".$address."',mail='".$mail."',contactno='".$mobile."',gstno='".$gstno."'");
		header("location:customers.php?msg=suc");
	}
	public function UpdateCustomer($id) { extract($_REQUEST);
		$customername=$this->clean('customer_name');			
			$mail=$this->clean('mail');
			$address=$this->clean('address');
			$mobile=$this->clean('mobile');
			$gstno=$this->clean('gstno');
			mysql_query("update cp_customers set customername='".$customername."',address='".$address."',mail='".$mail."',contactno='".$mobile."',gstno='".$gstno."' where customerid=".$id);
		header("location:customers.php?msg=upd");
	}
	public function DeleteCustomer($id) { extract($_REQUEST);
		mysql_query("delete from cp_customers where customerid=".$id);
		header("location:customers.php?msg=del");
	}

	/* Supplier */
	public function AddSupplier() { extract($_REQUEST); 
			$customername=$this->clean('customer_name');			
			$mail=$this->clean('mail');
			$address=$this->clean('address');
			$mobile=$this->clean('mobile');
			$gstno=$this->clean('gstno');
			mysql_query("insert into cp_suppliers set customername='".$customername."',address='".$address."',mail='".$mail."',contactno='".$mobile."',gstno='".$gstno."'");
		header("location:suppliers.php?msg=suc");
	}
	public function UpdateSupplier($id) { extract($_REQUEST);
		$customername=$this->clean('customer_name');			
			$mail=$this->clean('mail');
			$address=$this->clean('address');
			$mobile=$this->clean('mobile');
			$gstno=$this->clean('gstno');
			mysql_query("update cp_suppliers set customername='".$customername."',address='".$address."',mail='".$mail."',contactno='".$mobile."',gstno='".$gstno."' where id=".$id);
		header("location:suppliers.php?msg=upd");
	}
	public function DeleteSupplier($id) { extract($_REQUEST);
		mysql_query("delete from cp_suppliers where id=".$id);
		header("location:suppliers.php?msg=del");
	}

	//Products Master
	public function AddProduct() 
	{ 
		extract($_REQUEST);
		$purchase_name=$this->clean('purchase_name');
		$selling_name=$this->clean('selling_name');
		$hsnno=$this->clean('hsnno');
		
		mysql_query("insert into cp_product_master set purchasename='".$purchase_name."',sellingname='".$selling_name."',hsnno='".$hsnno."'");
		header("location:products.php?msg=suc");
	}
	public function UpdateProduct($id) 
	{ 
		extract($_REQUEST);
		$purchase_name=$this->clean('purchase_name');
		$selling_name=$this->clean('selling_name');
		$hsnno=$this->clean('hsnno');
		mysql_query("update cp_product_master set purchasename='".$purchase_name."',sellingname='".$selling_name."',hsnno='".$hsnno."' where productid=".$id);
		header("location:products.php?msg=upd");
	}
	public function DeleteProduct($id) 
	{ 
		extract($_REQUEST);
		mysql_query("delete from cp_product_master where productid=".$id);
		header("location:products.php?msg=del");
	}


	//Purchase
	public function AddPurchase(){
		extract($_REQUEST);
		mysql_query("insert into cp_purchase set invoice_no='".$invoice_no."', invoice_date='".date("Y-m-d",strtotime($invoice_date))."', parent_id='".$supplier."',posted_date='".date("Y-m-d H:i:s")."'");
		$pid=mysql_insert_id();
		$net_amount=0;
		foreach($_SESSION['items'] as $key=>$item){
			$product=$this->getRow("select * from cp_product_master where productid=".$item['productid']);
			$net_amount+=$item['total'];
			mysql_query("insert into cp_purchase_products set product_id='".$item['productid']."',hsnno='".$item['hsnno']."',qty='".$item['qty']."',rate='".$item['rate']."',gstpercen='".$item['gstpercen']."',gstamount='".$item['gstamount']."',total_amount='".$item['total']."',parent_id='".$pid."'");
			mysql_query("update cp_product_master set stock=stock+".$item['qty']." where productid=".$item['productid']);

			for($i=1;$i<=$item['qty'];$i++){
				mysql_query("insert into cp_purchase_product_items set purchase_id=".$pid.", product_id=".$item['productid']);
			}
		}
		mysql_query("update cp_purchase set total_amount='".$net_amount."' where id=".$pid);
		header("location:purchase.php?msg=suc");
	}
	public function UpdatePurchase($id){
		extract($_REQUEST);
		mysql_query("update cp_purchase set invoice_no='".$invoice_no."', invoice_date='".date("Y-m-d",strtotime($invoice_date))."', parent_id='".$supplier."',modified_date='".date("Y-m-d H:i:s")."' where id=".$id);
		$pid=$id;
		$net_amount=0;
		// Stock Delete
		$stocks=$this->getResults("select * from cp_purchase_products where parent_id=".$pid);
		if(!empty($stocks)){ $i=0;
			foreach ($stocks as $stock) {
				$pur_stock[$i]['pid']=$stock['product_id'];
				$pur_stock[$i]['qty']=$stock['qty'];
				mysql_query("update cp_product_master set stock=stock-".$stock['qty']." where productid=".$stock['product_id']);
				$i++;
			}
		}
		mysql_query("delete from cp_purchase_products where parent_id=".$pid);

		foreach($_SESSION['items'] as $key=>$item){
			$product=$this->getRow("select * from cp_product_master where productid=".$item['productid']);
			$net_amount+=$item['total'];
			mysql_query("insert into cp_purchase_products set product_id='".$item['productid']."',hsnno='".$item['hsnno']."', qty='".$item['qty']."',rate='".$item['rate']."',gstpercen='".$item['gstpercen']."',gstamount='".$item['gstamount']."',total_amount='".$item['total']."',parent_id='".$pid."'");
			mysql_query("update cp_product_master set stock=stock+".$item['qty']." where productid=".$item['productid']);
			// Sim / IEMI Update
			for($i=0;$i<count($pur_stock);$i++){
				if($pur_stock[$i]['pid']==$item['productid']){
					if($pur_stock[$i]['qty']>$item['qty']){
						mysql_query("delete * from cp_purchase_product_items limit ".($pur_stock[$i]['qty']-$item['qty']));
					} else if($pur_stock[$i]['qty']<$item['qty']){
						for($j=0;$j<($item['qty']-$pur_stock[$i]['qty']);$j++){
							mysql_query("insert into cp_purchase_product_items set purchase_id=".$pid.", product_id=".$item['productid']);
						}
					}
				}
			}


		}
		mysql_query("update cp_purchase set total_amount='".$net_amount."' where id=".$pid);
		header("location:purchase.php?msg=upd");
	}
	public function DeletePurchase($id){
		extract($_REQUEST);
		// Stock Delete
		$stocks=$this->getResults("select * from cp_purchase_products where parent_id=".$id);
		if(!empty($stocks)){
			foreach ($stocks as $stock) {
				mysql_query("update cp_product_master set stock=stock-".$stock['qty']." where productid=".$stock['product_id']);

			}
		}	
		mysql_query("delete from cp_purchase_product_items where purchase_id=".$id);
		mysql_query("delete from cp_purchase where id=".$id);
		mysql_query("delete from cp_purchase_products where parent_id=".$id);
		header("location:purchase.php?msg=del");
	}
	public function UpdateItems(){ 		
		foreach ($_POST as $key => $value) {
			mysql_query("update cp_purchase_product_items set detail='".$value."' where id='".$key."'");
			$id=$key;
		}
		$res=$this->getRow("select * from cp_purchase_product_items where id=".$id);
		header("location:purchase_products_items_update.php?msg=suc&pid=".$res['purchase_id']."&id=".$res['product_id']);
	}
	//Sales
	public function AddSales(){
		extract($_REQUEST);
		$linvno=$this->getRow("select * from cp_sales where bill_type='".$bill_type."' order by id desc");
		$invno=$linvno['invoice_no'];
		mysql_query("insert into cp_sales set invoice_date='".date("Y-m-d",strtotime($invoice_date))."', posted_date='".date("Y-m-d H:i:s")."', parent_id='".$supplier."', sale_type='".$sale_type."', bill_type='".$bill_type."'");
		$pid=mysql_insert_id();
		$net_amount=0; $gst_total=0;
		foreach($_SESSION['items'] as $key=>$item){
			$product=$this->getRow("select * from cp_product_master where productid=".$item['productid']);
			$net_amount+=$item['total'];
			$gst_total+=$item['gstamount'];
			mysql_query("insert into cp_sales_products set product_id='".$item['productid']."',description='".$item['description']."',hsnno='".$item['hsnno']."',qty='".$item['qty']."',rate='".$item['rate']."',discount='".$item['discount']."',gstpercen='".$item['gstpercen']."',gstamount='".$item['gstamount']."',total_amount='".$item['total']."',parent_id='".$pid."'");
			mysql_query("update cp_product_master set stock=stock-".$item['qty']." where productid=".$item['productid']);

			for($i=1;$i<=$item['qty'];$i++){
				mysql_query("insert into cp_sales_product_items set sales_id=".$pid.", product_id=".$item['productid']);
			}
		}
		$final_amount=$net_amount+$gst_total;

		mysql_query("update cp_sales set invoice_no='".($invno+1)."',total_amount='".$net_amount."',gst_amount='".$gst_total."',net_amount='".$final_amount."' where id=".$pid);
		mysql_query("update cp_customers set pending_amount=pending_amount+".$final_amount." where customerid=".$supplier);
		header("location:sales.php?msg=suc");
	}
	public function UpdateSales($id){
		extract($_REQUEST);
		$last=$this->getRow("select * from cp_sales where id=".$id);
		mysql_query("update cp_sales set invoice_date='".date("Y-m-d",strtotime($invoice_date))."', parent_id='".$supplier."', sale_type='".$sale_type."', bill_type='".$bill_type."',modified_date='".date("Y-m-d H:i:s")."' where id=".$id);
		$pid=$id;
		$net_amount=0; $gst_total=0;

		// Stock Delete
		$stocks=$this->getResults("select * from cp_sales_products where parent_id=".$pid);
		if(!empty($stocks)){
			foreach ($stocks as $stock) {
				mysql_query("update cp_product_master set stock=stock+".$stock['qty']." where productid=".$stock['product_id']);
			}
		}
		mysql_query("delete from cp_sales_products where parent_id=".$pid);

		
		foreach($_SESSION['items'] as $key=>$item){
			$product=$this->getRow("select * from cp_product_master where productid=".$item['productid']);
			$net_amount+=$item['total'];
			$gst_total+=$item['gstamount'];
			mysql_query("insert into cp_sales_products set product_id='".$item['productid']."',hsnno='".$item['hsnno']."',qty='".$item['qty']."',rate='".$item['rate']."',discount='".$item['discount']."',gstpercen='".$item['gstpercen']."',gstamount='".$item['gstamount']."',total_amount='".$item['total']."',parent_id='".$pid."'");
			mysql_query("update cp_product_master set stock=stock-".$item['qty']." where productid=".$item['productid']);
		}
		$final_amount=$net_amount+$gst_total;
		mysql_query("update cp_sales set total_amount='".$net_amount."',gst_amount='".$gst_total."',net_amount='".$final_amount."' where id=".$pid);

		if($last['net_amount']>$final_amount)
			mysql_query("update cp_customers set pending_amount=pending_amount-".($last['net_amount']-$final_amount)." where customerid=".$supplier);
		else if($last['net_amount']<$final_amount)
			mysql_query("update cp_customers set pending_amount=pending_amount+".($final_amount-$last['net_amount'])." where customerid=".$supplier);
		header("location:sales.php?msg=upd");
	}
	public function DeleteSales($id){
		extract($_REQUEST);
		// Stock Delete
		$res=$this->getRow("select * from cp_sales where id=".$id);
		$stocks=$this->getResults("select * from cp_sales_products where parent_id=".$id);
		if(!empty($stocks)){
			foreach ($stocks as $stock) {
				mysql_query("update cp_product_master set stock=stock+".$stock['qty']." where productid=".$stock['product_id']);
			}
		}	
		mysql_query("update cp_customers set pending_amount=pending_amount-".$res['net_amount']." where customerid=".$res['parent_id']);
		mysql_query("delete from cp_sales where id=".$id);
		mysql_query("delete from cp_sales_products where parent_id=".$id);
		header("location:sales.php?msg=del");
	}
	public function UpdateSoldItems(){ 	extract($_REQUEST);
		$results=$this->getResults("select * from cp_sales_product_items where sales_id='".$sid."' and product_id='".$id."'");
		if(!empty($results))	{
			foreach($results as $result){
				mysql_query("update cp_purchase_product_items set status='available' where detail='".$result['detail']."'");
			}
		}
		foreach ($_POST as $key => $value) {
			mysql_query("update cp_sales_product_items set detail='".$value."' where id='".$key."'");
			mysql_query("update cp_purchase_product_items set status='sold' where detail='".$value."'");
		}
		header("location:sales_products_items_update.php?msg=suc&pid=".$sid."&id=".$id);
	}
	
	public function ChangePassword($id){
		extract($_REQUEST);
		mysql_query("update cp_admin set userpassword='".md5($userpassword)."' where admin_id=".$id);
		header("location:users.php?msg=pass");
	}
	
	// Customer Payment
	public function AddCustomerPayment() 
	{ 
		extract($_REQUEST);
		$payment_date=date("Y-m-d",strtotime($payment_date));
		$payment_type=$this->clean('payment_type');
		$qry="";
		if($payment_type=='cheque'){
		$cheque_date=date("Y-m-d",strtotime($cheque_date));
		$cheque_no=$this->clean('cheque_no');
		$cheque_bank=$this->clean('cheque_bank');
		$qry.=",cheque_date='".$cheque_date."',cheque_no='".$cheque_no."',cheque_bank='".$cheque_bank."'";
		} else if($payment_type=='neft'){
		$neft_reffno=$this->clean('neft_reffno');
		$qry.=",neft_reffno='".$neft_reffno."'";
		}
		$amount_received=$amount;
		if($discount=='') $discount=0;
		$amount=$amount_received+$discount;
		mysql_query("insert into cp_customer_payments set parent_id='".$customer."',amount_received='".$amount_received."',discount='".$discount."',amount='".$amount."',payment_type='".$payment_type."',payment_date='".$payment_date."',posted_date='".date("Y-m-d H:i:s")."'".$qry);
		mysql_query("update cp_customers set pending_amount=pending_amount-".$amount." where customerid=".$customer);
		header("location:payments.php?msg=suc");
		
	}
	public function UpdateCustomerPayment($id) 
	{ 
		extract($_REQUEST);
		$res=$this->getRow("select * from cp_customer_payments where id=".$id);
		$payment_date=date("Y-m-d",strtotime($payment_date));
		$payment_type=$this->clean('payment_type');
		$qry="";
		if($payment_type=='cheque'){
		$cheque_date=date("Y-m-d",strtotime($cheque_date));
		$cheque_no=$this->clean('cheque_no');
		$cheque_bank=$this->clean('cheque_bank');
		$qry.=",cheque_date='".$cheque_date."',cheque_no='".$cheque_no."',cheque_bank='".$cheque_bank."'";
		} else if($payment_type=='neft'){
		$neft_reffno=$this->clean('neft_reffno');
		$qry.=",neft_reffno='".$neft_reffno."'";
		}
		$amount_received=$amount;
		if($discount=='') $discount=0;
		$amount=$amount_received+$discount;
		mysql_query("update cp_customer_payments set amount_received='".$amount_received."',discount='".$discount."',amount='".$amount."',payment_type='".$payment_type."',payment_date='".$payment_date."',posted_date='".date("Y-m-d H:i:s")."'".$qry." where id=".$id);
		// Update pending amount
		if($res['amount']>$amount)
		 mysql_query("update cp_customers set pending_amount=pending_amount+".($res['amount']-$amount)." where customerid=".$res['parent_id']);		
		else if($res['amount']<$amount)
		 mysql_query("update cp_customers set pending_amount=pending_amount-".($amount-$res['amount'])." where customerid=".$res['parent_id']);		

		header("location:payments.php?msg=update");
	}
	public function DeleteCustomerPayment($id) 
	{ 
		extract($_REQUEST);
		$res=$this->getRow("select * from cp_customer_payments where id=".$id);
		mysql_query("update cp_customers set pending_amount=pending_amount+".($res['amount'])." where customerid=".$res['parent_id']);
		mysql_query("delete from cp_customer_payments where id=".$id);
		header("location:payments.php?msg=del");
	}


	//Users
	public function AddUsers() 
	{ 
		extract($_REQUEST); 
		$personname=$this->clean('personname');
		$username=$this->clean('username');
		$userpassword=md5($this->clean('userpassword'));
		mysql_query("insert into cp_admin set personname='".$personname."',username='".$username."',userpassword='".$userpassword."',date_added='".date("Y-m-d H:i:s")."',category='employee'");
		$id=mysql_insert_id();
		if(!isset($customers_view)) $view='no'; else $view='yes';
		if(!isset($customers_add)) $add='no'; else $add='yes';
		if(!isset($customers_edit)) $edit='no'; else $edit='yes';
		if(!isset($customers_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='customer', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($suppliers_view)) $view='no'; else $view='yes';
		if(!isset($suppliers_add)) $add='no'; else $add='yes';
		if(!isset($suppliers_edit)) $edit='no'; else $edit='yes';
		if(!isset($suppliers_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='supplier', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($purchase_view)) $view='no'; else $view='yes';
		if(!isset($purchase_add)) $add='no'; else $add='yes';
		if(!isset($purchase_edit)) $edit='no'; else $edit='yes';
		if(!isset($purchase_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='purchase', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($sales_view)) $view='no'; else $view='yes';
		if(!isset($sales_add)) $add='no'; else $add='yes';
		if(!isset($sales_edit)) $edit='no'; else $edit='yes';
		if(!isset($sales_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='sales', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($payments_view)) $view='no'; else $view='yes';
		if(!isset($payments_add)) $add='no'; else $add='yes';
		if(!isset($payments_edit)) $edit='no'; else $edit='yes';
		if(!isset($payments_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='payments', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($products_view)) $view='no'; else $view='yes';
		if(!isset($products_add)) $add='no'; else $add='yes';
		if(!isset($products_edit)) $edit='no'; else $edit='yes';
		if(!isset($products_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='products', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");

		if(!isset($reports_view)) $view='no'; else $view='yes';
		if(!isset($reports_add)) $add='no'; else $add='yes';
		if(!isset($reports_edit)) $edit='no'; else $edit='yes';
		if(!isset($reports_delete)) $delete='no'; else $delete='yes';
		mysql_query("insert into cp_access set module='reports', parent_id='".$id."', access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."'");
		header("location:users.php?msg=suc");
	}
	public function UpdateUsers($id) 
	{ 
		extract($_REQUEST);
		$personname=$this->clean('personname');
		$username=$this->clean('username');
		$userpassword=md5($this->clean('userpassword'));
		mysql_query("update cp_admin set personname='".$personname."',username='".$username."' where admin_id=".$id);
		
		if(!isset($customers_view)) $view='no'; else $view='yes';
		if(!isset($customers_add)) $add='no'; else $add='yes';
		if(!isset($customers_edit)) $edit='no'; else $edit='yes';
		if(!isset($customers_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='customer' and parent_id='".$id."'");
		
		mysql_query("update cp_access set access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='customer' and parent_id='".$id."'");

		if(!isset($suppliers_view)) $view='no'; else $view='yes';
		if(!isset($suppliers_add)) $add='no'; else $add='yes';
		if(!isset($suppliers_edit)) $edit='no'; else $edit='yes';
		if(!isset($suppliers_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='supplier' and parent_id='".$id."'");
		
		mysql_query("update cp_access set access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='supplier' and parent_id='".$id."'");

		if(!isset($purchase_view)) $view='no'; else $view='yes';
		if(!isset($purchase_add)) $add='no'; else $add='yes';
		if(!isset($purchase_edit)) $edit='no'; else $edit='yes';
		if(!isset($purchase_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='purchase' and parent_id='".$id."'");
		
		mysql_query("update cp_access set  access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='purchase' and parent_id='".$id."'");

		if(!isset($sales_view)) $view='no'; else $view='yes';
		if(!isset($sales_add)) $add='no'; else $add='yes';
		if(!isset($sales_edit)) $edit='no'; else $edit='yes';
		if(!isset($sales_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='sales' and parent_id='".$id."'");
		
		mysql_query("update cp_access set  access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='sales' and parent_id='".$id."'");

		if(!isset($payments_view)) $view='no'; else $view='yes';
		if(!isset($payments_add)) $add='no'; else $add='yes';
		if(!isset($payments_edit)) $edit='no'; else $edit='yes';
		if(!isset($payments_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='payments' and parent_id='".$id."'");
		
		mysql_query("update cp_access set  access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='payments' and parent_id='".$id."'");

		if(!isset($products_view)) $view='no'; else $view='yes';
		if(!isset($products_add)) $add='no'; else $add='yes';
		if(!isset($products_edit)) $edit='no'; else $edit='yes';
		if(!isset($products_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='products' and parent_id='".$id."'");
		
		mysql_query("update cp_access set access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='products' and parent_id='".$id."'");

		if(!isset($reports_view)) $view='no'; else $view='yes';
		if(!isset($reports_add)) $add='no'; else $add='yes';
		if(!isset($reports_edit)) $edit='no'; else $edit='yes';
		if(!isset($reports_delete)) $delete='no'; else $delete='yes';
		mysql_query("update cp_access set access_view='no', access_add='no', access_edit='no', access_delete='no' where module='reports' and parent_id='".$id."'");
		
		mysql_query("update cp_access set access_view='".$view."', access_add='".$add."', access_edit='".$edit."', access_delete='".$delete."' where module='reports' and parent_id='".$id."'");
		header("location:users.php?msg=upd");
	}
	public function DeleteUsers($id) 
	{ 
		extract($_REQUEST);
		mysql_query("delete from cp_admin where admin_id=".$id);
		mysql_query("delete from cp_access where parent_id=".$id);
		header("location:users.php?msg=del");
	}
	public function SendInvoice($id){
		$destinationpath=DIR_PDF;
		$qry="";
		if($_FILES['pdf_file']['name']!="")
			 { 
				$rnd=rand(999,10000);
				$image_path =$rnd."_".basename($_FILES['pdf_file']['name']);
				$tmp=$_FILES['pdf_file']['tmp_name'];
				$targetpath=$destinationpath.$image_path;
				move_uploaded_file($tmp,$targetpath);
				//mysql_query("update cp_projects set pdf_file='".$image_path."' where id=".$id);
			 } 
		$sales=$this->getRow("select * from cp_sales where id=".$id);
		$customer=$this->getRow("select * from cp_customers where customerid='".$sales['parent_id']."'");
		// Sent Email 
		require_once(DIR_LIB.'PHPMailer/class.phpmailer.php');

$mail             = new PHPMailer(); // defaults to using php "mail()"

//MAIL WRITTEN 
	$body  ='<div style="font-family:\'Lucida Grande\',\'Lucida Sans Unicode\',Helvetica,Arial,Verdana,sans-serif;font-size:12px;background-color:#ffffff;color:#333333"><div class="adM">
	</div><div style="width:800px;text-align:left"><div class="adM">
		</div><div style="background-color:#ffffff;border:#e5e5e5 solid 1px"><div class="adM">
			</div><div style="background-color:#f4f4f4;min-height:36px">Company Name SOLUTIONS</a>
			</div>
			<div style="padding:10px;line-height:18px">
				<div style="font-size:12px">Sir, <br>Good Day!!!</div>
				<div style="font-size:12px;padding:10px 0 0 0"">Welcome to HITECH SOLUTIONS for a safe & secure world.<br></div>
				<div style="font-size:12px;padding:10px 0 0 0"">Thanks for purchase from HITECH SOLUTIONS.<br></div>
				<div style="font-size:12px;padding:10px 0 0 0"">Herewith i\'m sending the Invoice Kindly have a look on that.,</div>

				<div style="font-size:12px;padding:10px 0px 0px 0px">Please revert me back for further clarification, if any.</div>
				<br><br>
				<u><b>Contact Details</b></u><br>
				<b>HITECH SOLUTIONS</b><br>
				<b>Customer Care</b>: +91 8489 8489 79<br>
				<b>Email</b>: hitechsolutions.service@gmail.com<br>
				<div style="font-size:12px;padding:10px 0 0 0;line-height:16px">
					Thank you<div class="yj6qo ajU"><div id=":187" class="ajR" role="button" tabindex="0" aria-label="Hide expanded content" data-tooltip="Hide expanded content"><img class="ajT" src="//ssl.gstatic.com/ui/v1/icons/mail/images/cleardot.gif"></div></div><span class="HOEnZb adL"><font color="#888888"><br><span class="il">Company Name SOLUTIONS </span> Team<br> 
				</font></span></div><span class="HOEnZb adL"><font color="#888888">
			</font></span></div><span class="HOEnZb adL"><font color="#888888">
		</font></span></div><span class="HOEnZb adL"><font color="#888888">
		<div style="padding:5px 0px 0px 10px">
			
		</div>
	</font></span></div><div class="adL">
</div></div>';

$mail->AddReplyTo("service@hitecsolutions.in","Company Name SOLUTIONS");

$mail->SetFrom('service@hitecsolutions.in', 'Company Name SOLUTIONS');

$address = $customer['mail'];
$mail->AddAddress($address, $res['customername']);

$mail->Subject    = 'Invoice';

$mail->MsgHTML($body);

$mail->AddAttachment(DIR_PDF.$image_path);      // attachment

if(!$mail->Send()) {
  echo "Mailer Error: " . $mail->ErrorInfo;
} else {
  echo "Message sent!";
}
	
	header("location:sales.php?msg=pdf");
	

	}
}
$objFeatures = new Features();
?>