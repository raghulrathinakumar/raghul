<?php
$module = @$_REQUEST['module'];
$action = @$_REQUEST['action'];
switch ($module) 
	{
	case 'admin':
		switch($action)
			{
			case 'suppliers':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddSupplier();
			} else if($do == 'update'){
				$objFeatures->UpdateSupplier($id);
			} else if($do == 'delete'){
				$objFeatures->DeleteSupplier($id);
			} 
			break;
			case 'customers':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddCustomer();
			} else if($do == 'update'){
				$objFeatures->UpdateCustomer($id);
			} else if($do == 'delete'){
				$objFeatures->DeleteCustomer($id);
			} 
			break;
			case 'product':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddProduct();
			} else if($do == 'update'){
				$objFeatures->UpdateProduct($id);
			} else if($do == 'delete'){
				$objFeatures->DeleteProduct($id);
			} 
			break;
			case 'purchase':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddPurchase($id);
			}  else if($do == 'update'){
				$objFeatures->UpdatePurchase($id);
			}  else if($do == 'delete'){
				$objFeatures->DeletePurchase($id);
			} 
			break;
			case 'sales':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddSales($id);
			}  else if($do == 'update'){
				$objFeatures->UpdateSales($id);
			}  else if($do == 'delete'){
				$objFeatures->DeleteSales($id);
			} 
			break;
			case 'customer_payment':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddCustomerPayment();
			} else if($do == 'update'){
				$objFeatures->UpdateCustomerPayment($id);
			} else if($do == 'delete'){
				$objFeatures->DeleteCustomerPayment($id);
			} 
			break;
			case 'users':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->AddUsers();
			} else if($do == 'update'){
				$objFeatures->UpdateUsers($id);
			} else if($do == 'delete'){
				$objFeatures->DeleteUsers($id);
			} else if($do == 'changepass'){
				$objFeatures->ChangePasswordUsers($id);
			} 
			break;

			case 'purchase_product_items':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->UpdateItems();
			} 
			break;
			case 'sales_product_items':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'add'){
				$objFeatures->UpdateSoldItems();
			} 
			break;
			case 'changepassword':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];
			if($do == 'update'){
				$objFeatures->UpdatePassword();
			} 
			break;
			case 'sendinvoice':
			$do = @$_REQUEST['do'];
			$id = @$_REQUEST['id'];			
				$objFeatures->SendInvoice($id);
	
			break;
		}
	}
?>