<?php
extract($_REQUEST);
require_once 'connection.php';
require_once 'functions.php';
if($_REQUEST['type']=='add') {
		
		if($rate!="" && $rate!=0 && $qty!="" && $qty!=0){			
			if(!isset($_SESSION['items']) || count($_SESSION['items'])==0){ 
				$gstamount=(((($rate*$qty)-$discount)*$gstpercen)/100);
				$total=($rate*$qty)-$discount;
				$_SESSION['items'][0]['productid']=$productid;
				$_SESSION['items'][0]['description']=$description;
				$_SESSION['items'][0]['rate']=$rate;
				$_SESSION['items'][0]['qty']=$qty;
				$_SESSION['items'][0]['discount']=$discount;
				$_SESSION['items'][0]['gstpercen']=$gstpercen;
				$_SESSION['items'][0]['gstamount']=$gstamount;
				$_SESSION['items'][0]['total']=$total;
			} else if(count($_SESSION['items'])>0){ 
				$keys = array_keys($_SESSION['items']);
				$last = end($keys);
				$id=$last+1;
				$gstamount=(((($rate*$qty)-$discount)*$gstpercen)/100);
				$total=($rate*$qty)-$discount;
				$_SESSION['items'][$id]['productid']=$productid;
				$_SESSION['items'][$id]['description']=$description;
				$_SESSION['items'][$id]['rate']=$rate;
				$_SESSION['items'][$id]['qty']=$qty;
				$_SESSION['items'][$id]['discount']=$discount;
				$_SESSION['items'][$id]['gstpercen']=$gstpercen;
				$_SESSION['items'][$id]['gstamount']=$gstamount;
				$_SESSION['items'][$id]['total']=$total;
			}
		}
		$msg=''; $net_amount=0;
		foreach($_SESSION['items'] as $key=>$item){		
			if($item['productid']!=-1){
			$product=$objMain->getRow("select * from cp_product_master where productid=".$item['productid']);
			$pname=$product['purchasename'];
			} else $pname=$item['newproduct'];
			$net_amount+=$item['total'];
			$msg.='<tr><td>'.$pname.'</td><td>'.$item['description'].'</td><td>'.$item['qty'].'</td><td>'.$item['rate'].'</td><td>'.($item['rate']*$item['qty']).'</td><td>'.$item['discount'].'</td><td>'.$item['gstpercen'].'</td><td>'.$item['total'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">Remove</a></td></tr>';
		}
			
			$msg.='<tr><td colspan=7 align=right>Net Amount</td><td>'.$net_amount.'</td><td></td></tr>';

		echo $msg;
} else if($_REQUEST['type']=='update') {
		
		unset($_SESSION['items'][$id]);
		$msg=''; $net_amount=0;
		foreach($_SESSION['items'] as $key=>$item){
			$product=$objMain->getRow("select * from cp_product_master where productid=".$item['productid']);
			$pname=$product['sellingname'];
			$net_amount+=$item['total'];
			$msg.='<tr><td>'.$pname.'</td><td>'.$item['description'].'</td><td>'.$item['qty'].'</td><td>'.$item['rate'].'</td><td>'.($item['rate']*$item['qty']).'</td><td>'.$item['discount'].'</td><td>'.$item['gstpercen'].'</td><td>'.$item['gstamount'].'</td><td>'.$item['total'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">Remove</a></td></tr>';
		}
		$msg.='<tr><td colspan=7 align=right>Net Amount</td><td>'.$net_amount.'</td><td></td></tr>';
		echo $msg;
} else if($_REQUEST['type']=='find') {
		
		$result=$objMain->getRow("select * from cp_product_master where productid=".$productid);
		echo $result['sellingname'];
} else if($_REQUEST['type']=='load') {
		
		$purchase_products=$objMain->getResults("select * from cp_sales_products where parent_id=".$id);
		if(!empty($purchase_products)){ $i=0;
			foreach($purchase_products as $pproduct){
				$sell=$objMain->getRow("select * from cp_product_master where productid=".$pproduct['product_id']);
				$_SESSION['items'][$i]['productid']=$pproduct['product_id'];
				$_SESSION['items'][$i]['description']=$pproduct['description'];				
				$_SESSION['items'][$i]['rate']=$pproduct['rate'];
				$_SESSION['items'][$i]['qty']=$pproduct['qty'];
				$_SESSION['items'][$i]['discount']=$pproduct['discount'];
				$_SESSION['items'][$i]['gstpercen']=$pproduct['gstpercen'];
				$_SESSION['items'][$i]['gstamount']=$pproduct['gstamount'];
				$_SESSION['items'][$i]['total']=$pproduct['total_amount'];
				$i++;
			}
		}
						
		$msg=''; $net_amount=0;
		foreach($_SESSION['items'] as $key=>$item){		
			$product=$objMain->getRow("select * from cp_product_master where productid=".$item['productid']);
			$pname=$product['purchasename'];
			$net_amount+=$item['total'];
			$msg.='<tr><td>'.$pname.'</td><td>'.$item['description'].'</td><td>'.$item['qty'].'</td><td>'.$item['rate'].'</td><td>'.($item['rate']*$item['qty']).'</td><td>'.$item['discount'].'</td><td>'.$item['gstpercen'].'</td><td>'.$item['total'].'</td><td><a class="btn btn-danger btn-sm" onclick="update_item('.$key.')">Remove</a></td></tr>';
		}			
			$msg.='<tr><td colspan=7 align=right>Net Amount</td><td>'.$net_amount.'</td><td></td></tr>';
		echo $msg;
} else if($_REQUEST['type']=='imei') {
		
		echo "document.getElementById('hsnno').options.length=0;";	
		echo "document.getElementById('hsnno').options[0]=new Option('Select','0');";
		$qry="select * from cp_purchase_products where product_id=".$_REQUEST['id']." and stock in ('yes')";
		$rs=mysql_query($qry);
		if(mysql_num_rows($rs)>0) { $i=1;	
		while($row=mysql_fetch_array($rs))	{
		echo "document.getElementById('hsnno').options[$i]=new Option('".str_replace("'","",ucfirst($row['hsnno']))."','".$row['id']."');";
		$i++;
		} }	
}
?>