<?php require_once 'lib/common.php'; require_once 'lib/session_check.php'; $menu='customers'; 
$result=$objMain->getRow("select * from cp_customers where customerid=".$id);
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Cstomers Update | Company Name</title>
<?php include("inc/header_scripts.php"); ?>
<style>
      .example-modal .modal {
        position: relative;
        top: auto;
        bottom: auto;
        right: auto;
        left: auto;
        display: block;
        z-index: 1;
      }
      .example-modal .modal {
        background: transparent!important;
      }
    </style>
  </head>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">

      <?php include("inc/top_navi.php"); ?>
      <!-- Left side column. contains the logo and sidebar -->
      <?php include("inc/sidebar.php"); ?>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Update Customers
          </h1>
        </section>

        <!-- Main content -->
        <section class="content">
          <div class="row">
          
          <form role="form" class="form-horizontal" method="post" action="init.php?module=admin&action=customers&do=update&id=<?php echo $id; ?>" enctype="multipart/form-data">
            <!-- left column -->
            <!--/.col (left) -->
            <!-- right column -->
            <div class="col-md-6">
              <!-- Horizontal Form -->
              <div class="box box-info">
                <div class="box-header with-border">
                  
                </div><!-- /.box-header -->
                <!-- form start -->
                
                  <div class="box-body">
                  <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Cutomer Name</label>
                      <div class="col-sm-8">
                       <input type="text" class="form-control" placeholder="Customer Name" id="customer_name" name="customer_name" data-validation="length" data-validation-length="min3" data-validation-error-msg="Please provide Customer Name" value="<?php echo $result['customername']; ?>" required; />
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Customer Address</label>
                      <div class="col-sm-8">
                      <textarea class="form-control" placeholder="Customer Address" id="address" name="address" required;/> <?php echo $result['address']; ?></textarea>
                      </div>
                    </div>
                    <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">GSTIN</label>
                      <div class="col-sm-8">
                      <input type="text" class="form-control" placeholder="GSTIN" id="gstno" name="gstno" required; data-validation-error-msg="Please provide Customer Name" value="<?php echo $result['gstno']; ?>">
                      </div>
                    </div>
                    </fieldset>
                    <fieldset>
                      <legend>Contact Details</legend>
                      <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Mobile Number</label>
                      <div class="col-sm-8">
                     <input type="text" class="form-control"  id="mobile" name="mobile" pattern="[7-9]{1}[0-9]{9}" placeholder="Contact Person Mobile Number" required; value="<?php echo $result['contactno']; ?>"/>
                      </div>
                    </div>
                     <div class="form-group">
                      <label for="type" class="col-sm-4 control-label">Mail ID</label>
                      <div class="col-sm-8">
                       <input type="email" class="form-control" placeholder="Company Email Id" required id="mail" name="mail" data-validation="length" data-validation-length="min3" data-validation-error-msg="Please provide Company Email ID" required; value="<?php echo $result['mail']; ?>"/>
                      </div>
                    </div>
                    </fieldset>
                   
                    
                    <div class="box-footer">
                    <button type="submit" class="btn btn-info pull-right">Submit</button>
                  </div>
                    
                  </div><!-- /.box-body -->
                
              </div><!-- /.box -->
              <!-- general form elements disabled -->
              <!-- /.box -->
            </div><!--/.col (right) -->
            
            
            
            
            
            </form>
          </div>
          
          
        <!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      <?php include("inc/footer_line.php"); ?>
      <div class="control-sidebar-bg"></div>
    </div><!-- ./wrapper -->

   <?php include("inc/footer_scripts.php"); ?>
 <script type="text/javascript">
$(document).ready(function () {
  //called when key is pressed in textbox
  $("#contact_phone").keypress(function (e) { 
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) { return false;  } 
   });
  
});
</script>
  </body>
</html>
